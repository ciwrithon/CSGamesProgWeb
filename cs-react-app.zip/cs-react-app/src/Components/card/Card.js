import { React } from "react";

function Card() {
    return (
        <h1>Hi</h1>
    );
}

export default Card;